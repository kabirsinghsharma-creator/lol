document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.main-nav');

  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    nav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  var currentPage = (window.location.pathname.split('/').pop() || 'index.html');
  document.querySelectorAll('.main-nav a').forEach(function (link) {
    var href = link.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      link.classList.add('active');
    }
  });

  var form = document.querySelector('[data-join-form]');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var name = form.querySelector('#name').value.trim();
      var grade = form.querySelector('#grade').value.trim();
      var email = form.querySelector('#email').value.trim();
      var experience = form.querySelector('#experience').value;
      var message = form.querySelector('#message').value.trim();

      var bodyLines = [
        'Name: ' + name,
        'Grade: ' + grade,
        'Email: ' + email,
        'MUN Experience: ' + experience,
        '',
        'Message:',
        message
      ];

      var mailto = 'mailto:pgmuncamp@gmail.com'
        + '?subject=' + encodeURIComponent('PGHS MUN Membership Interest — ' + name)
        + '&body=' + encodeURIComponent(bodyLines.join('\n'));

      window.location.href = mailto;

      var success = document.querySelector('.form-success');
      if (success) {
        success.classList.add('visible');
        success.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    });
  }
});
